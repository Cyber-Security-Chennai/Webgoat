#!/usr/bin/env bash

cd ..
docker-compose up
