package org.owasp.webgoat.plugin;

/**
 * Interface with constants so we can easily change the flags
 *
 * @author nbaars
 * @since 3/23/17.
 */
public interface SolutionConstants {

    //TODO should be random generated when starting the server
    String PASSWORD = "!!webgoat_admin_1234!!";
    String PASSWORD_TOM = "thisisasecretfortomonly";
    String ADMIN_PASSWORD_LINK = "375afe1104f4a487a73823c50a9292a2";
}
